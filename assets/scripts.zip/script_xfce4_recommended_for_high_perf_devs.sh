yes | termux-setup-storage
apt update
yes | apt upgrade -y
apt update
apt install -y pulseaudio openssh proot-distro
echo "Your Termux/ssh username is: "$(whoami)
echo "Set your ssh password:"
passwd
sed -i 's/\; exit-idle-time = 20/exit-idle-time = -1/g' $PREFIX/etc/pulse/daemon.conf
echo "load-module module-native-protocol-tcp auth-ip-acl=127.0.0.1 auth-anonymous=1" >> $PREFIX/etc/pulse/default.pa
proot-distro install ubuntu
proot-distro login ubuntu -- apt-mark unhold gvfs-daemons udisks2
proot-distro login ubuntu -- apt update
proot-distro login ubuntu -- apt install -y apt-utils dialog
proot-distro login ubuntu -- apt upgrade -y
proot-distro login ubuntu -- apt install -y command-not-found pulseaudio-utils zsh git gcc g++ nano file procps curl wget man xfce4 xfce4-goodies xfce4-terminal tightvncserver
proot-distro login ubuntu -- apt update
proot-distro login ubuntu -- wget -O /root/install.sh https://raw.github.com/ohmyzsh/ohmyzsh/master/tools/install.sh
proot-distro login ubuntu -- sh /root/install.sh
proot-distro login ubuntu -- rm /root/install.sh
proot-distro login ubuntu -- zsh -lc ". /root/.zshrc;omz plugin enable command-not-found colored-man-pages;omz theme set clean"
echo "export PULSE_SERVER=127.0.0.1" >> $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/.zshrc
proot-distro login ubuntu -- vncpasswd
echo '#!/bin/sh\nif [ -f $HOME/.Xresources ]; then\n\txrdb "$HOME/.Xresources"\nfi\nxsetroot -solid grey\nexport XKL_XMODMAP_DISABLE=1\n/etc/X11/Xsession\ndbus-launch --exit-with-session startxfce4\nexport PULSE_SERVER=127.0.0.1' > $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/.vnc/xstartup
echo '$PREFIX/bin/sshd' > ~/.bashrc
echo "pulseaudio --start" >> ~/.bashrc
echo 'proot-distro login --fix-low-ports --isolated --bind /sdcard --bind /data/data/com.termux:/TermuxData --bind /:/AndroidRootFolder ubuntu' >> ~/.bashrc
echo "exit" >> ~/.bashrc

